var firstName = prompt("What is your first name?");
var lastName = prompt("What is your first firstName?");
var age = prompt("What is your first name?");
console.log("Hello Nice to meet you "+ name + " " + lastName);
console.log("you are " + age + " years old.");
stop();